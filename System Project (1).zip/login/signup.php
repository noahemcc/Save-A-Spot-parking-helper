<?php
require "header.php";
?>

<main>
<h1>Signup</h1>
<?php
if (isset($_GET["error"])) {
    if ($_GET["error"] == "emptyfields") {
        echo "<p class="signuperror"> Fill in all fields!</p>";
    }
    else if ($_GET["error"] == "invailduidmail") {
        echo "<p class="signuperror"> Invalid username and e-mail!</p>";
    }
    else if ($_GET["error"] == "invailduid") {
        echo "<p class="signuperror"> Invalid username!</p>";
    }
    else if ($_GET["error"] == "invaildmail") {
        echo "<p class="signuperror"> Invalid e-mail!</p>";
    }
    else if ($_GET["error"] == "passwordcheck") {
        echo "<p class="signuperror">Your passwords don't match</p>";
    }
    else if ($_GET["error"] == "usertaken") {
        echo "<p class="signuperror"> username is already taken</p>";
    }
}
else if ($_GET["signup"] == "success") {
    echo "<p class="signupsuccess">Signup successful!</p>";
}
?>
<form action="includes/signup.inc.php" method="post">
<input type="text" name="uid" placeholder="username">
<input type="text" nmae="mail" placeholder="E-mail">
<input tpye="password" name="pwd" placeholder="password">
<input tpye="password" name="pwd-repeat" placeholder="Repeat password">
<button tpye="submit" name="signup-submit">Signup</button>
</form>
</main>

<?php
require "footer.php";
?>