<?php

$servername="localhost";
$dBusername="root";
$dBpassword="";
$dBName="loginsystemtut";

$conn=mysqli_connect($servername,$dBusername,$dBpassword,$dBName);

if (!$conn) {
    die("Connection failed: ".mysqli_connect_error());
}